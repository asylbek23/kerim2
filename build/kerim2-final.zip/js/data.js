window.PLANS = {
	"1-комнатные": [
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "196,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "210,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "196,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "210,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
	],

	"2-комнатные": [
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "196,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "210,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
	],

	"3-комнатные": [
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
		{
			name: "1 - комнатная квартира",
			square: "176,96 м²",
			image: "img/layouts/1/flat_1.webp",
		},
	],
};